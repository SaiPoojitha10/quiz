import colorama
from colorama import Fore,Back,Style
colorama.init()
print(Fore.GREEN+"HELLO FRIENDS WELCOME TO OUR CODING BUDDIES CHANNEL")
print(Back.BLUE+"Hi Friends my name Kritika")
print(Fore.RED+Back.GREEN+"This Is Our Coding Buddies Channel")
print(Style.BRIGHT+"Do Like Share And Subscribe")
