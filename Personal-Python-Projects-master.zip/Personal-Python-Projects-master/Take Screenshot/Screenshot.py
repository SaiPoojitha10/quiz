import pyautogui
myscreenshot = pyautogui.screenshot()
myscreenshot.save("Enter your location")
