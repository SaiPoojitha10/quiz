import qrcode
url='Coding Buddies'
code_image =qrcode.make(url)
code_image.save('Enter your Location')
